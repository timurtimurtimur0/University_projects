﻿using System;
using System.Security.Cryptography;
namespace Name
{
    class Program{
    static void Main(string[] args){
        Random rnd1 = new Random();
        Console.WriteLine("Перше завдання:");
        List<int> chisla1 = new List<int>();
        for (int i = 0; i < 10; i++){
            chisla1.Add(rnd1.Next(15, 56));
            Console.Write(" " + chisla1[i] + ",");
        }              
        Console.WriteLine(" ");
        
        for (int i = 0; i < chisla1.Count; i++){
            
            if((chisla1[i]%3==0)||(chisla1[i]%5==0)) {
                chisla1.RemoveAt(i);
                break;
            }    
        }
        System.Console.WriteLine(" ");
        for (int i = 0; i < chisla1.Count; i++){
            Console.Write(" " + chisla1[i] + ",");
        }   


        Console.WriteLine("\nДруге завдання:");
        Random rnd2 = new Random();
        int X = rnd2.Next(5, 51);
        List<int> chisla2 = new List<int>();
        for (int i = 0; i < 10; i++){
            chisla2.Add(rnd1.Next(5, 51));
            Console.Write(" " + chisla2[i] + ",");
        }              
        System.Console.WriteLine("\n" + "X = " + X);
        
        for (int i = 0; i < chisla2.Count; i++){
            
            if(chisla2[i] < X) {
                chisla2.Insert(i, X);
                i++;

            }    
        }
        System.Console.WriteLine(" ");
        for (int i = 0; i < chisla2.Count; i++){
            Console.Write(" " + chisla2[i] + ",");
        } 

        Console.WriteLine("\nТретє завдання:");
        Random rnd3 = new Random();
        List<int> chisla3 = new List<int>();
        List<int> chisla31 = new List<int>();
        for (int i = 0; i < 10; i++){
            chisla3.Add(rnd3.Next(10, 100));
            Console.Write(" " + chisla3[i] + ",");
        }              
        Console.WriteLine(" ");

        for (int i = 0; i < chisla3.Count; i++){
            
            if(chisla3[i] % 3 == 0) {
                chisla31.Add(chisla3[i]);
                chisla3.Remove(chisla3[i]);
            }    
        }
        Console.WriteLine(" ");
        for (int i = 0; i < chisla31.Count; i++){
            Console.Write(" " + chisla31[i] + ",");
        }  
        
        Console.WriteLine(" ");
        for (int i = 0; i < chisla3.Count; i++){
            Console.Write(" " + chisla3[i] + ",");
        }  

        

    }
}


}