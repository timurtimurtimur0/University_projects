﻿using System; 

class Program
{
    struct Meteo
    {
        public string tigd;
        public int temp;
        public int opad;

        public string Vivod()
        {
            string s = tigd + " " + Convert.ToString(temp) + " " + Convert.ToString(opad);
            return s;
        }
    }

    static void Main(string[] args)
    {
        List<Meteo> meteo = new List<Meteo>();
        Meteo met; 
        int n = 5;
        
        for (int i = 0; i < n; i++)
        {
            met.tigd = Console.ReadLine();
            met.temp = Convert.ToInt32(Console.ReadLine());
            met.opad = Convert.ToInt32(Console.ReadLine());
            meteo.Add(met);
        }
        System.Console.WriteLine("\n");

        for (int i = 0; i < n; i++)
        {
            System.Console.WriteLine(meteo[i].Vivod());
        }
        
        int N = 0;

        for (int i = 0; i < n; i++)
        {
            if (meteo[i].temp <= 0)
            {
                N++;
            }
            
        }
        System.Console.WriteLine("Кількість днів зі снігом: " + N);

        int K = 0;
        for (int i = 0; i < n; i++)
        {
            if (meteo[i].temp > 0)
            {
                K += meteo[i].opad;
            }
            
        }
        System.Console.WriteLine("Загальна кількість опадів дощу: " + K);




    }

}