﻿using System;
namespace ConsoleApp36 {
    class Program {
    
    static void Main(string[] args) {

        Console.WriteLine("Перше завдання: ");       
        Console.WriteLine("Введіть кількість рядків і стовпців у квадратній матриці: ");
        int M = Convert.ToInt32(Console.ReadLine());    
        int [,] Arr = new int [M, M]; 
        int i, j;
        Random rnd = new Random();
        Console.WriteLine("Початкова матриця:");
        for (i = 0; i < M; ++i){
            for (j = 0; j < M; ++j){
                int num = rnd.Next(0, 5);
                Arr[i, j] = Convert.ToInt32(num);
            }
        }
        for (i = 0; i < M; ++i){
            for (j = 0; j < M; ++j){
                Console.Write(" " + Arr[i, j]);
            }
            Console.WriteLine();
        }
        Console.WriteLine("\nКінцева матриця:");
        for (i = 0; i < M; ++i){
            for (j = 0; j < M; ++j){
                if (Arr[i, j] == 0){
                    Arr [i, j] = Convert.ToInt32(Arr[M - 1, j]);
                    Arr[M - 1, j] = 0;
                }
                
                Console.Write(" " + Arr[i, j]);
            }
            Console.WriteLine();
        }
        
        
        Console.WriteLine("\nДруге завдання: ");
        
        float sum = 0;
        float N = 0;
        float Res = 0;
        int [,] Arr1 = new int [4, 4];
        int [,] Arr2 = new int [3, 3];
        int [,] Arr3 = new int [2, 2];

        for (i = 0; i < 4; ++i){
            for (j = 0; j < 4; ++j){
                int num = rnd.Next(-100, 101);
                Arr1[i, j] = Convert.ToInt32(num);
                
                if ((i == j) && Arr1[i, j] > 0){
                    sum = sum + Arr1 [i, j];
                    N++;
                } 
            }
        }
        
        for (i = 0; i < 4; ++i){
            for (j = 0; j < 4; ++j){
                Console.Write(" " + Arr1[i, j]);
            }
            Console.WriteLine();
        }   

        if (N > 0){
            Res = sum / N;
            Console.WriteLine("Середнє арифметичне позитивних членів головної діагоналі: " + Res);
        }
        else{
            Console.WriteLine("В головній діагоналі немає додатніх членів");
        }


        sum = 0;
        N = 0;
        Res = 0;

        for (i = 0; i < 3; ++i){
            for (j = 0; j < 3; ++j){
                int num = rnd.Next(-100, 101);
                Arr2[i, j] = Convert.ToInt32(num);
                
                if ((i == j) && Arr2[i, j] > 0){
                    sum = sum + Arr2 [i, j];
                    N++;
                } 
            }
        }
        
        for (i = 0; i < 3; ++i){
            for (j = 0; j < 3; ++j){
                Console.Write(" " + Arr2[i, j]);
            }
            Console.WriteLine();
        }   

        if (N > 0){
            Res = sum / N;
            Console.WriteLine("Середнє арифметичне позитивних членів головної діагоналі: " + Res);
        }
        else{
            Console.WriteLine("В головній діагоналі немає додатніх членів");
        }


        sum = 0;
        N = 0;
        Res = 0;

        for (i = 0; i < 2; ++i){
            for (j = 0; j < 2; ++j){
                int num = rnd.Next(-100, 101);
                Arr3[i, j] = Convert.ToInt32(num);
                
                if ((i == j) && Arr3[i, j] > 0){
                    sum = sum + Arr3 [i, j];
                    N++;
                } 
            }
        }
        
        for (i = 0; i < 2; ++i){
            for (j = 0; j < 2; ++j){
                Console.Write(" " + Arr3[i, j]);
            }
            Console.WriteLine();
        }   

        if (N > 0){
            Res = sum / N;
            Console.WriteLine("Середнє арифметичне позитивних членів головної діагоналі: " + Res);
        }
        else{
            Console.WriteLine("В головній діагоналі немає додатніх членів");
        }


    }
}

}