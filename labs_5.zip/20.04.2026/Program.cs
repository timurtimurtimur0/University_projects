﻿using System;
using System.Formats.Asn1;
using System.Security.Cryptography.X509Certificates;
using Program;

namespace Program
{
    class RivnTr
    {
        public double osn, bichna; 
        public RivnTr()
        {
            System.Console.WriteLine("Введіть основу трикутника: ");
            osn = Convert.ToDouble(Console.ReadLine());
            System.Console.WriteLine("Введіть бічну сторону трикутника: ");
            bichna = Convert.ToDouble(Console.ReadLine());
        }
        public bool isValid()
        {
            if (osn > 0 && bichna > 0 && (2 * bichna > osn))
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public double P()
        {
            return (bichna * 2) + osn;
        }
        public double S()
        {
            double height = Math.Sqrt(Math.Pow(bichna, 2) - Math.Pow(osn / 2.0, 2));
            return 0.5 * osn * height;
        }
        public void Result()
        {
            Console.WriteLine("Дані трикутника: ");
            Console.WriteLine("Основа: " + osn + " Бічна сторона: " + bichna);

            if (isValid() == true)
            {
                Console.WriteLine("Трикутник побудувати можливо");
                Console.WriteLine("Периметр: " + P());
                Console.WriteLine("Площа: " + S());
            }
            else
            {
                Console.WriteLine("Помилка у введені даних");
            }
            Console.WriteLine();
        }           
    
        
    }
    class Coord {       
            
        public double x1, y1;

        public Coord()  {            
            System.Console.WriteLine("Введіть координату x");
            x1 = Convert.ToDouble(Console.ReadLine());

            System.Console.WriteLine("Введіть координату y");
            y1 = Convert.ToDouble(Console.ReadLine());            
            
        }
        public double Area() {
        return Math.Abs(x1*y1);
        }

        public void Result()
        {
            Console.WriteLine("Координати: ");
            Console.WriteLine("X: " + x1 + " Y: " + y1);
            System.Console.WriteLine("Площа прямокутника обмеженого координатами та осями: " + Area());
            
        }
            
        
    }
    class Program
    {        
        static void Main(string[] args)
        {
            Console.WriteLine("Перше завдання: ");
            RivnTr tr = new RivnTr();
            tr.Result();

            Console.WriteLine("Друге завдання: ");
            Coord cor = new Coord();
            cor.Result();
            
            
        }
    }
}
