﻿using System;
using System.Security.Cryptography.X509Certificates;

namespace Program
{
    class Mas
    {
        public int K, N;
        
        public int[] mas;
        public Mas()
        {
            K = 22;
            N = (int)Math.Round(20 + (0.6 * K));
            System.Console.WriteLine("Розмір масиву: " + N);
            mas = new int[N];

            Random random = new Random();            
            for (int i = 0; i < N; i++)
            {                
                mas[i] = random.Next(10, 101);
            }
            for (int i = 0; i < mas.Length; i++)
            {
                System.Console.Write(mas[i] + ", ");
            }            

        }
        
    }
    class Sort
    {
        
    public static int IndexOfMin(int[] mas, int N)
    {
        int result = N;
        for (var i = N; i < mas.Length; i++)
        {
            if (mas[i] < mas[result])
            {
                result = i;
            }
        }

        return result;
    }

    public static void Swap(ref int x, ref int y)
    {
        var t = x;
        x = y;
        y = t;
    }

    public static int[] SelectionSort(int[] mas, int currentIndex = 0)
    {
        if (currentIndex == mas.Length)
            return mas;

        var index = IndexOfMin(mas, currentIndex);
        if (index != currentIndex)
        {
            Swap(ref mas[index], ref mas[currentIndex]);
        }

        return SelectionSort(mas, currentIndex + 1);
    }

    public static void CW(int[] mas)
    {
        System.Console.WriteLine("\nПісля сортування вибором: ");
        for(int i = 0; i < mas.Length; i++)
            {
                System.Console.Write(mas[i] + ", ");
            }
            
    }
        
    }
    class Poshuk
    {        
        public int cluch()
        {
            Console.WriteLine("\nВведіть ключове значення в массиві: ");
            return Convert.ToInt32(Console.ReadLine());

        }
        public static int C(int[] mas, int cluch)
        {
            int Count = 0;
            for (int i = 0; i < mas.Length; i++)
                {
                if (mas[i] == cluch)
                Count++;
            }
            return Count;
        }
        public static int BinarySearch(int[] mas, int cluch, int first, int last)
            {
                                
                if (first > last)
                {
                    return -1;
                }

                var middle = (first + last) / 2;
                var middleValue = mas[middle];

                if (middleValue == cluch)
                {
                    return middle;
                }
                else
                {
                    if (middleValue > cluch)
                    {
                        return BinarySearch(mas, cluch, first, middle - 1);
                    }
                    else
                    {
                        return BinarySearch(mas, cluch, middle + 1, last);
                    }
                }
            }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Mas obj = new Mas();
            Sort.SelectionSort(obj.mas);
            Sort.CW(obj.mas);
            
            Poshuk p = new Poshuk();
            
            int cluch = p.cluch();
            int index = Poshuk.BinarySearch(obj.mas, cluch, 0, obj.mas.Length - 1);  
            int count = Poshuk.C(obj.mas, cluch);          

            Console.WriteLine("\nПозиція першого ключа: " + index);
            System.Console.WriteLine("Кількість повторень ключового значення: " + count);
                       
            
        }
    }
  }

