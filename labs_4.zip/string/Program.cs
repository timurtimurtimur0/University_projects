﻿using System; 

class Program {
    static void Main(string[] args)
    {
        System.Console.WriteLine("Перше Завдання: ");
        System.Console.WriteLine("Введіть рядок: ");
        char l;
        int p = 0, k = 0, n = 0;        

        string S = Console.ReadLine();
        System.Console.WriteLine("Введіть літеру: ");
        l = Convert.ToChar(Console.ReadLine());
        p = S.Length;
        for(int i = 0; i < p; i++)
        {
            if(S[i] == l) k++;
            if(S[i] == ' ') n++;
        }
        System.Console.WriteLine("Кількість літер в рядку: " + k);
        if (n < 2)
        {
            System.Console.WriteLine("В рядку менше двох прогалин!");
        }        
        
        System.Console.WriteLine("\nДруге Завдання: ");
        System.Console.WriteLine("Введіть рядок: ");
        string str = Convert.ToString(Console.ReadLine());
        string str3 = str;
        string str4 = str; 
        System.Console.WriteLine("Введіть перший символ: ");         
        char symv1 = Convert.ToChar(Console.ReadLine());
        System.Console.WriteLine("Введіть другий символ: ");         
        char symv2 = Convert.ToChar(Console.ReadLine());
        System.Console.WriteLine("Введіть третій символ: ");         
        char symv3 = Convert.ToChar(Console.ReadLine());
        int n2 = 0;
        n2 = str.LastIndexOf(symv3);
        if (n2 == -1)
        {
            System.Console.WriteLine("В рядку немає третього символу!");

        }
        else
        {
            char[] str2 = str.ToCharArray();
            for(int i = 0; i < n2; i++)
        {
            if (str2[i] == symv1)
            {
                str2[i] = symv2;
            }
            str = new string(str2);

        }
        }       

        System.Console.WriteLine(str);

        
        System.Console.WriteLine("\nТретє Завдання: ");
        for (int i = 0; i < (str3.Length / 2); i++)
        {
            if(str3[i] == symv1)
            {
                str3 = str3.Remove(i, 1);
                i--;
            }
        }
        System.Console.WriteLine("Рядок без першого символа symv1: " + str3);
        
        System.Console.WriteLine("\nЧетверте Завдання: ");
        string R = "";

        for (int i = 0; i < str4.Length; i++)
        {
            if (char.IsLetter(str4[i]))
            {
                R +="_";
            }          
            R += str4[i];
        }
        System.Console.WriteLine("Результат: " + R);
    }
}